
from handlers.portfolio_handler import PortfolioHandler
from config import PATH_ACTIVITY


def main():

    # Run the Portfolio Handler to populate the model
    ph = PortfolioHandler(PATH_ACTIVITY)

    # Generate reports
        # Nice graphs - bokeh preferably
        # taxable transactions
        # current balance
        # current metrics
        # current value


    return


if __name__ == "__main__":



    main()